<body style="background-size: cover; background-position: center;  background-repeat: no-repeat;background-image: url('<?php echo base_url()?>assets/img/admin.png');">
        <!-- Header-->
        <section class="admin">
            <div class="container px-4 px-lg-5 text-center">
                <h1 class="mb-1">PENGELOLAAN PRODUK</h1>
                <br><br><br><br>
                <a class="btn btn-primary btn-xl" href="<?php echo base_url('admin/data_mobil') ?>">Update Produk</a>
                <br><br><br><br>
                <a class="btn btn-primary btn-xl" href="<?php echo base_url('admin/promo') ?>">Update Info Promo&Event</a>
            </div>
        </section>
        