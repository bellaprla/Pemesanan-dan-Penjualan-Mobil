<body style="background-size: cover; background-position: center;  background-repeat: no-repeat;background-image: url('<?php echo base_url()?>assets/img/manager.png');">
        
        <!-- Header-->
        <section class="marketing">
            <div class="container px-4 px-lg-5 text-center">
                <h1 class="mb-1">LAPORAN</h1><br>
                <br>
                <br>
                <br>
                <br>
                <br>
                <br>
                <a class="btn btn-primary btn-xl" href="<?php echo base_url('manajer/pemesananmobil') ?>">Laporan</a>
            </div>
        </section>
        <!-- About-->