<body style="background-size: cover; background-position: center;  background-repeat: no-repeat;background-image: url('<?php echo base_url()?>assets/img/marketing.png');">
        
        <!-- Header-->
        <section class="marketing">
            <div class="container px-4 px-lg-5 text-center">
                <h1 class="mb-1">PEMESANAN</h1>
                <br><br>
                <a class="btn btn-primary btn-xl" href="<?php echo base_url('marketing/pemesananmobil') ?>">Terima Pemesan</a>
                <br><br><br>
                <a class="btn btn-primary btn-xl" href="<?php echo base_url('marketing/pemesananmobil') ?>">Lihat Pemesan</a>
                <br><br><br>
                <a class="btn btn-primary btn-xl" href="<?php echo base_url('marketing/pemesananmobil') ?>">Laporan</a>
            </div>
        </section>
        <!-- About-->