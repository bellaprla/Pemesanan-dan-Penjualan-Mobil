<div class="text-center text-white mt-2 pt-2 font-weight-bold" style=" background-color:  #234BBF">
        <p class="mt-2">Developed by Bela dan Romy Copyright <i class="far fa-copyright"></i> 2022</p>
</div>