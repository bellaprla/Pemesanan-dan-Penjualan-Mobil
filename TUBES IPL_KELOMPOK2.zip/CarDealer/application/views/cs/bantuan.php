<body style="background-size: cover; background-position: center;  background-repeat: no-repeat;background-image: url('<?php echo base_url()?>assets/img/cs.png');">
        <!-- Navigation-->
        
        <!-- Header-->
        <section class="cs">
            <div class="container px-4 px-lg-5 text-center">
                <h1 class="mb-1">BANTUAN</h1>
                <br><br>
                <a class="btn btn-primary btn-xl" href="<?php echo base_url('cs/pesan') ?>">Lihat Pesan</a>
                <br><br><br>
                <a class="btn btn-primary btn-xl" href="<?php echo base_url('cs/pesan') ?>">Balas Pesan</a>
            </div>
        </section>