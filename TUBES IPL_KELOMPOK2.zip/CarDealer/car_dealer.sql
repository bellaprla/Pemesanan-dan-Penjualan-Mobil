-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 01, 2023 at 08:26 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `car_dealer`
--

-- --------------------------------------------------------

--
-- Table structure for table `form_pemesanan`
--

CREATE TABLE IF NOT EXISTS `form_pemesanan` (
  `id_pemesanan` int(5) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `merk_mobil` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `no_hp` int(12) NOT NULL,
  `catatan` varchar(1000) NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY (`id_pemesanan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mobil`
--

CREATE TABLE IF NOT EXISTS `mobil` (
  `id_mobil` int(11) NOT NULL AUTO_INCREMENT,
  `merk` varchar(120) NOT NULL,
  `kategori` varchar(120) NOT NULL,
  `harga` int(11) NOT NULL,
  `warna` varchar(50) NOT NULL,
  `gambar` varchar(150) NOT NULL,
  PRIMARY KEY (`id_mobil`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `mobil`
--

INSERT INTO `mobil` (`id_mobil`, `merk`, `kategori`, `harga`, `warna`, `gambar`) VALUES
(1, 'Creta Active 6-Speed MT', 'Hyundai Creta', 288500000, 'Merah', 'Hyundai-Creta.jpg'),
(2, 'All New HR-V S CVT', 'Honda HR-V', 365000000, 'Putih', 'HR-V.jpg'),
(3, ' Kijang Innova 2.0 G MT', 'Toyota Kijang Innova', 396500000, 'Abu-Abu', 'kijang-Innova.jpg'),
(5, 'New Xpander GLS MT', 'Hyundai Creta', 254000000, 'Silver', 'New-Xpander.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `pesan`
--

CREATE TABLE IF NOT EXISTS `pesan` (
  `id_pesan` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `no_hp` varchar(20) NOT NULL,
  `pesan_bantuan` text NOT NULL,
  `pesan_balasan` text NOT NULL,
  PRIMARY KEY (`id_pesan`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `pesan`
--

INSERT INTO `pesan` (`id_pesan`, `nama`, `email`, `no_hp`, `pesan_bantuan`, `pesan_balasan`) VALUES
(1, 'Romy', 'romy@gmail.com', '081345678905', 'Tidak bisa menekan tombol beli', 'Baik kak, segera kami segera perbaiki'),
(2, 'Romy', 'romy@gmail.com', '081345678905', 'baik kak', '');

-- --------------------------------------------------------

--
-- Table structure for table `pesanan`
--

CREATE TABLE IF NOT EXISTS `pesanan` (
  `id_pesanan` int(11) NOT NULL AUTO_INCREMENT,
  `id_mobil` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `no_hp` varchar(50) NOT NULL,
  `merk` varchar(50) NOT NULL,
  `harga` int(11) NOT NULL,
  PRIMARY KEY (`id_pesanan`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `pesanan`
--

INSERT INTO `pesanan` (`id_pesanan`, `id_mobil`, `nama`, `alamat`, `no_hp`, `merk`, `harga`) VALUES
(4, 2, 'romi', 'bangko', '0812864081624', 'All New HR-V S CVT', 365000000);

-- --------------------------------------------------------

--
-- Table structure for table `promo`
--

CREATE TABLE IF NOT EXISTS `promo` (
  `id_promo` int(11) NOT NULL AUTO_INCREMENT,
  `gambar` varchar(150) NOT NULL,
  PRIMARY KEY (`id_promo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `promo`
--

INSERT INTO `promo` (`id_promo`, `gambar`) VALUES
(1, 'slider1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `nama_user` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(50) NOT NULL,
  `no_hp` varchar(50) NOT NULL,
  `role_id` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama_user`, `username`, `password`, `email`, `no_hp`, `role_id`) VALUES
(1, 'admin', 'admin', '$2y$10$kv5tTX4zMF7Bw0bmGNoWKesbRwP1mPgaQ4aWYAsrDD2twYH/8NPIS', 'admin@gmail.com', '081231213214', 1),
(3, 'romi', 'Romy', '$2y$10$/9KYkeC1G0DLgqjR5uh7ueW1604VDOelMt5DUyvKplPoU1sNaGa0y', 'romy@gmail.com', '081345678905', 2),
(5, 'cs', 'cs', '$2y$10$yDOgE54DaV8E1E3oM7Ff6.rDZGVzf8iqavgGGuJ2nIv0DXD/dCIi2', 'cs@gmail.com', '089625122131', 3),
(6, 'marketing', 'marketing', '$2y$10$vG6BnGRZM/zuclz7ceeSM.Zy6sPNsEFQP3E4nlA4HrWId0qUDigC6', 'marketing@gmail.com', '081231210231', 5),
(7, 'manajer', 'manajer', '$2y$10$J5xSbRENhGUMbbZTQZlHkuaWN3oK7aac.nrZzbhl2C/mO8KCtK7j2', 'manajer@gmail.com', '081312321312', 4),
(8, 'customer', 'customer', '$2y$10$EUkIrtMYtSJVDCh8ZH.yeel7XYU1yO3pZBAJ/qIba1MsZYH9ibclK', 'customer@gmail.com', '0812139426298', 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
